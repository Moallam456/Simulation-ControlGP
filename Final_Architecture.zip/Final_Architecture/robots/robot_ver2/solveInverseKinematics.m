function solutions = solveInverseKinematics(targetPose,robot,options)
% SOLVEINVERSEKINEMATICS Validate the control team's closed-form IK against URDF FK.

if nargin < 3 || isempty(options)
    options = struct();
end
validateTarget(targetPose);

dof = robot.structure.dof;
limits = robot.params.joints.positionLimits;
qSeed = reshape(option(options,'qSeed',robot.params.joints.homePosition),1,[]);
if numel(qSeed) ~= dof || any(~isfinite(qSeed))
    error('robot_ver2:InvalidIKSeed','qSeed must contain %d finite angles.',dof);
end
qSeed = min(max(qSeed,limits(:,1).'),limits(:,2).');
positionTolerance = option(options,'positionTolerance',1e-5);
orientationTolerance = option(options,'orientationTolerance',1e-4);
if ~isscalar(positionTolerance) || ~isfinite(positionTolerance) || positionTolerance <= 0 || ...
        ~isscalar(orientationTolerance) || ~isfinite(orientationTolerance) || orientationTolerance <= 0
    error('robot_ver2:InvalidIKTolerance','IK tolerances must be positive finite scalars.');
end

solverFolder = fullfile(fileparts(fileparts(fileparts(fileparts(mfilename('fullpath'))))), ...
    'RecentIK','RecentIK');
if ~isfile(fullfile(solverFolder,'ikSolver.m')) || ...
        ~isfile(fullfile(solverFolder,'robotParams.m'))
    error('robot_ver2:MissingAnalyticalIK', ...
        'The control-team IK files are missing from %s.',solverFolder);
end
addpath(solverFolder,'-begin');
cleanup = onCleanup(@() rmpath(solverFolder)); %#ok<NASGU>
P = robotParams();
P.qmin = limits(:,1).';
P.qmax = limits(:,2).';
Ttool = robot.params.tool.TFlangeTCP;
targetEE = targetPose / Ttool;
[~,candidates,diagnostic] = ikSolver(targetEE,qSeed,P);

[q,pError,rError] = validatedCandidates(candidates,robot,targetPose, ...
    Ttool,limits,positionTolerance,orientationTolerance);
if ~isempty(q)
    delta = atan2(sin(q-qSeed),cos(q-qSeed));
    [~,order] = sort(sum(delta.^2,2));
    q = q(order,:);
    pError = pError(order);
    rError = rError(order);
end

solutions.q = q;
solutions.valid = ~isempty(q);
solutions.branch = repmat("analytical",size(q,1),1);
solutions.info.success = solutions.valid;
solutions.info.numSolutions = size(q,1);
solutions.info.iterations = 0;
solutions.info.method = "analytical_closed_form";
solutions.info.positionErrors = pError;
solutions.info.orientationErrors = rError;
solutions.info.positionError = Inf;
solutions.info.orientationError = Inf;
solutions.info.analyticalStatus = "URDF_FK_VALIDATED";
solutions.info.collisionStatus = ...
    "NOT_FILTERED: mesh collisions require a separate collision check.";
if solutions.valid
    solutions.info.positionError = pError(1);
    solutions.info.orientationError = rError(1);
    solutions.info.message = "Closed-form IK branches validated against URDF forward kinematics.";
else
    solutions.info.message = "No FK-validated, limit-valid closed-form branch: " + diagnostic.reason;
end
end

function validateTarget(T)
if ~isequal(size(T),[4 4]) || any(~isfinite(T(:))) || ...
        norm(T(4,:)-[0 0 0 1]) > 1e-10 || ...
        norm(T(1:3,1:3).'*T(1:3,1:3)-eye(3),'fro') > 1e-8 || ...
        det(T(1:3,1:3)) < 0
    error('robot_ver2:InvalidTargetPose', ...
        'Target must be a finite, proper 4-by-4 rigid transform.');
end
end

function value = option(options,name,defaultValue)
if isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end

function [q,pError,rError] = validatedCandidates( ...
        candidates,robot,target,Ttool,limits,pTolerance,rTolerance)
q = zeros(0,robot.structure.dof);
pError = zeros(0,1);
rError = zeros(0,1);
for i = 1:size(candidates,1)
    candidate = candidates(i,:);
    if any(candidate < limits(:,1).'-1e-9 | candidate > limits(:,2).'+1e-9)
        continue;
    end
    achieved = getTransform(robot.model,candidate, ...
        char(robot.structure.frames.endEffector)) * Ttool;
    pe = norm(achieved(1:3,4)-target(1:3,4));
    relativeRotation = target(1:3,1:3).'*achieved(1:3,1:3);
    re = acos(max(-1,min(1,(trace(relativeRotation)-1)/2)));
    if pe > pTolerance || re > rTolerance
        continue;
    end
    wrappedDifference = atan2(sin(q-candidate),cos(q-candidate));
    if ~isempty(q) && any(vecnorm(wrappedDifference,2,2) < 1e-6)
        continue;
    end
    q(end+1,:) = candidate; %#ok<AGROW>
    pError(end+1,1) = pe; %#ok<AGROW>
    rError(end+1,1) = re; %#ok<AGROW>
end
end
