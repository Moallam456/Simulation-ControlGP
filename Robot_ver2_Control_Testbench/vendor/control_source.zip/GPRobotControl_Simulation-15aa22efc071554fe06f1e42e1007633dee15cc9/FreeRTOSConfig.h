#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#include <assert.h>

#define configUSE_PREEMPTION                    1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 0
#define configUSE_TICKLESS_IDLE                 0

#define configTICK_RATE_HZ                      1000
#define configMAX_PRIORITIES                    5
#define configMINIMAL_STACK_SIZE                128
#define configMAX_TASK_NAME_LEN                 16

#define configUSE_16_BIT_TICKS                  0
#define configIDLE_SHOULD_YIELD                 1

#define configUSE_TASK_NOTIFICATIONS            1
#define configTASK_NOTIFICATION_ARRAY_ENTRIES   1

#define configUSE_MUTEXES                       1
#define configUSE_RECURSIVE_MUTEXES             1
#define configUSE_COUNTING_SEMAPHORES           1
#define configQUEUE_REGISTRY_SIZE               8

#define configUSE_TIMERS                        0
#define configUSE_CO_ROUTINES                   0

#if defined(ROBOT_FREERTOS_STATIC)
#define configSUPPORT_STATIC_ALLOCATION         1
#else
#define configSUPPORT_STATIC_ALLOCATION         0
#endif
#define configSUPPORT_DYNAMIC_ALLOCATION        1

/* The SIL Kit POSIX host runs an additional 4096-word validation task.
 * Reserve a larger host-only heap for task stacks and queues. This does NOT
 * allocate additional SRAM on STM32 targets; the MCU still uses 64 KiB here.
 * MCU task stacks and memory placement require separate measurement. */
#if defined(POSIX_ASYNC_VALIDATION_HEAP)
#define configTOTAL_HEAP_SIZE                   (128 * 1024)
#else
#define configTOTAL_HEAP_SIZE                   (64 * 1024)
#endif

#define configUSE_IDLE_HOOK                     0
#define configUSE_TICK_HOOK                     0
#define configCHECK_FOR_STACK_OVERFLOW          0
#define configUSE_MALLOC_FAILED_HOOK            0

#define configUSE_TRACE_FACILITY                0
#define configGENERATE_RUN_TIME_STATS           0

#define INCLUDE_vTaskDelay                      1
#define INCLUDE_vTaskDelayUntil                 1
#define INCLUDE_vTaskDelete                     1
#define INCLUDE_xTaskGetCurrentTaskHandle       1
#define INCLUDE_xTaskGetSchedulerState          1

#define configASSERT(x) assert(x)

#endif
